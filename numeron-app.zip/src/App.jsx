import React, { useState } from 'react';

function App() {
  return (
    <div className="min-h-screen bg-white text-black flex flex-col items-center p-4">
      <header className="text-4xl font-bold my-4">Numeron</header>
      <p>ゲーム本体はここに入ります（後で追加）</p>
    </div>
  );
}

export default App;
